### OBD2 DBC ###

This OBD2 DBC demo contains most of the standardized OBD2 PIDs from Mode 01.
It does not contain proprietary PIDs, though you can freely expand the DBC as you see fit.

Note that the OBD2 DBC uses complex multiplexing to achieve conversion of the data. 
This follows the DBC standard, but few tools support it.

You can, however, use it with the asammdf GUI/API, which works with the CANedge series.
This lets you directly convert raw OBD2 data logged as MDF4 files from the CANedge - into human-readable form.
In the asammdf GUI you can then e.g. easily plot the data.

-----------------------------------------------------------------------
### RELEVANT LINKS ### 

- CANedge series: https://www.csselectronics.com/screen/overview
- CANedge MDF4 log file tools: https://canlogger.csselectronics.com/canedge-getting-started/log-file-tools/
- Configuring your CANedge for OBD2 logging: https://canlogger.csselectronics.com/canedge-getting-started/tips-and-tricks/
- Contact us: https://www.csselectronics.com/screen/page/can-bus-logger-contact