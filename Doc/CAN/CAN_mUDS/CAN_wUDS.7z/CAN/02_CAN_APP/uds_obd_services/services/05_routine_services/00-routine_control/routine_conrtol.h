#ifndef ROUTINE_CONRTOL_H
#define ROUTINE_CONRTOL_H

#include "Platform_Types.h"
#include "uds_parameters.h"

uint8 routine_control(struct iso15765_tp_s* response_message, struct iso15765_tp_s*  request_message);



#endif /* ROUTINE_CONRTOL_H */
