#ifndef ECU_RESET_PRIVATE_H
#define ECU_RESET_PRIVATE_H

#define ER_LEN	2
/* subfunctions*/
#define HR		0x01
#include "ecu_reset.h"


#endif /* ECU_RESET_PRIVATE_H */
