#ifndef CLEAR_DTC_INFORMATION_H
#define CLEAR_DTC_INFORMATION_H

#include "Platform_Types.h"
#include "uds_parameters.h"

extern uint8 clear_dtc_information(struct iso15765_tp_s* response_message, struct iso15765_tp_s*  request_message);

#endif /* CLEAR_DTC_INFORMATION_H */
