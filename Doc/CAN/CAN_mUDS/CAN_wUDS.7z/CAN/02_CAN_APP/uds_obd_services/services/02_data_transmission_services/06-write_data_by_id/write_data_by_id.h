#ifndef WRITE_DATA_BY_ID_H
#define WRITE_DATA_BY_ID_H

#include "Platform_Types.h"
#include "uds_parameters.h"

extern void write_data_by_id(struct iso15765_tp_s*  response_message, struct iso15765_tp_s* request_message);

#endif /* WRITE_DATA_BY_ID_H */
