#ifndef REQUEST_VEHICLE_INFORMATION_H
#define REQUEST_VEHICLE_INFORMATION_H

#include "Platform_Types.h"
#include "uds_parameters.h"

extern void request_vehicle_information(struct iso15765_tp_s* response_message, struct iso15765_tp_s* request_message);

#endif /* REQUEST_VEHICLE_INFORMATION_H */
