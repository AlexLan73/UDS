#ifndef CONTROL_DTC_SETTING_H
#define CONTROL_DTC_SETTING_H

#include "Platform_Types.h"
#include "uds_parameters.h"
extern void control_dtc_setting(struct data_units* response_message,struct data_units* request_message);

#endif /* CONTROL_DTC_SETTING_H */
