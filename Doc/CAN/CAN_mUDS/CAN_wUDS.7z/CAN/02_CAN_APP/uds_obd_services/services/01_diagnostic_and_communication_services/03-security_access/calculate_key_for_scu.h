#ifndef CALCULATE_KEY_FOR_SCU_H
#define CALCULATE_KEY_FOR_SCU_H

#include "Platform_Types.h"

uint32 calculate_scu_key(uint32 seed);


#endif /* CALCULATE_KEY_FOR_SCU_H */
