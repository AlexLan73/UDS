#ifndef WRITE_RESPONSE__MESSAGE_H
#define WRITE_RESPONSE__MESSAGE_H

#include "Platform_Types.h"
#include "can_tp_iso15765_parameters.h"

extern void write_response_message(struct iso15765_tp_s* message);


#endif /* WRITE_RESPONSE__MESSAGE_H */
