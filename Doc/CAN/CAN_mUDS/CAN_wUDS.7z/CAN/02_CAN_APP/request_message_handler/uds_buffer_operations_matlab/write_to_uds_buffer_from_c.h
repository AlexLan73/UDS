#ifndef WRITE_TO_UDS_BUFFER_FROM_C_H
#define WRITE_TO_UDS_BUFFER_FROM_C_H

#include "Platform_Types.h"
uint16 write_1byte_to_uds_buffer_from_c(uint8 data, uint8* to,uint16 size, uint16* current_position);



#endif /* WRITE_TO_UDS_BUFFER_FROM_C_H */
