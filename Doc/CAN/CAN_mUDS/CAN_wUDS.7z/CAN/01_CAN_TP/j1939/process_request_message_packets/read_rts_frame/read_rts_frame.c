#include "read_rts_frame.h"

void read_rts_frame(struct j1939_tp_s* instance)
{

}


