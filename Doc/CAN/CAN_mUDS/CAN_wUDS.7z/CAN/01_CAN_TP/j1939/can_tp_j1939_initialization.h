#ifndef CAN_TP_J1939_INITIALIZATION_H
#define CAN_TP_J1939_INITIALIZATION_H

#include "Platform_Types.h"

extern void can_tp_j1939_initialization(void);

#endif /* CAN_TP_J1939_INITIALIZATION_H */
