#ifndef CAN_TP_INITIALIZATION_H
#define CAN_TP_INITIALIZATION_H

#include "Platform_Types.h"
void can_tp_initialization(void);


#endif /* CAN_TP_INITIALIZATION_H */
