#ifndef READ_CONSECUTIVEFRAME_H
#define READ_CONSECUTIVEFRAME_H

#include "Platform_Types.h"
#include "can_tp_iso15765_parameters.h"

void read_consecutiveframe(struct iso15765_tp_s* instance);
#endif /* READ_CONSECUTIVEFRAME_H */
