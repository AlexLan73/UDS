#ifndef READ_FIRSTFRAME_H
#define READ_FIRSTFRAME_H

#include "Platform_Types.h"
#include "can_tp_iso15765_parameters.h"

boolean read_firstframe(struct iso15765_tp_s* instance);

#endif /* READ_FIRSTFRAME_H */
