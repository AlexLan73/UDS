#ifndef WRITE_CONSECUTIVEFRAME_H
#define WRITE_CONSECUTIVEFRAME_H

#include "Platform_Types.h"
#include "can_tp_iso15765_parameters.h"

extern void write_consecutiveframe(struct iso15765_tp_s* instance);

#endif /* WRITE_CONSECUTIVEFRAME_H */
