#ifndef WRITE_CONSECUTIVEFRAME_PRIVATE_H
#define WRITE_CONSECUTIVEFRAME_PRIVATE_H

#include "extract_data_from_buffer.h"
#include "write_consecutiveframe.h"
#include "can_write_frame.h"

static void add_cf_pdu(struct iso15765_tp_s* instance);

#endif /* WRITE_CONSECUTIVEFRAME_PRIVATE_H */
