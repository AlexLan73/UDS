#ifndef WRITE_SINGLEFRAME_H
#define WRITE_SINGLEFRAME_H

#include "Platform_Types.h"
#include "can_tp_iso15765_parameters.h"

extern void write_singleframe(struct iso15765_tp_s* instance);

#endif /* WRITE_SINGLEFRAME_H */
