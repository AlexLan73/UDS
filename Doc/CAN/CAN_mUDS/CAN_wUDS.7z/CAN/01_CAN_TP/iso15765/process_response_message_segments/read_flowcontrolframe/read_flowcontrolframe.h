#ifndef READ_FLOWCONTROLFRAME_H
#define READ_FLOWCONTROLFRAME_H

#include "Platform_Types.h"
#include "can_tp_iso15765_parameters.h"

extern void read_flowcontrolframe(struct iso15765_tp_s* instance);

#endif /* READ_FLOWCONTROLFRAME_H */
