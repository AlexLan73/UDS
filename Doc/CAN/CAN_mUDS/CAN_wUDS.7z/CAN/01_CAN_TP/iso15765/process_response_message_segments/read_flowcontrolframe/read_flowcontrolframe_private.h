#ifndef READ_FLOWCONTROLFRAME_PRIVATE_H
#define READ_FLOWCONTROLFRAME_PRIVATE_H

#include "read_flowcontrolframe.h"

#include "tx_fsm.h"
#include "tp_timers.h"

#endif /* READ_FLOWCONTROLFRAME_PRIVATE_H */
