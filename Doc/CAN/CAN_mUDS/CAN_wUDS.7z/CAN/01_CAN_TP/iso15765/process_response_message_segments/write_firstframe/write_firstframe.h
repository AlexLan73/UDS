#ifndef WRITE_FIRSTFRAME_H
#define WRITE_FIRSTFRAME_H

#include "Platform_Types.h"
#include "can_tp_iso15765_parameters.h"
extern void write_firstframe(struct iso15765_tp_s* instance);

#endif /* WRITE_FIRSTFRAME_H */
