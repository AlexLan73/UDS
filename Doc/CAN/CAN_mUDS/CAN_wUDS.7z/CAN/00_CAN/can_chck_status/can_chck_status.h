#ifndef CAN_FRAME_CHCK_STATUS_H
#define CAN_FRAME_CHCK_STATUS_H
#include "Platform_Types.h"
#include "can_frame_status.h"
enum can_status_e can_frame_chck_status(uint32 can_id);
#endif /* CAN_FRAME_CHCK_STATUS_H */
