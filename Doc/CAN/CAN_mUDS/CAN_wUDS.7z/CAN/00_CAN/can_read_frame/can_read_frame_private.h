#ifndef CAN_READ_FRAME_PRIVATE_H
#define CAN_READ_FRAME_PRIVATE_H
#include "can_read_frame.h"
#include "can_initialization.h"

static IfxMultican_Message msg;

#endif
