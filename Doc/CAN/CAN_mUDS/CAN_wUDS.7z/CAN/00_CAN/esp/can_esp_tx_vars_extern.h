#include "can_esp_tx_vars.h"
extern uint32 count_ECU_15;
extern ECU_15 ECU_15_frame;
