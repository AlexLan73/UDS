#include "can_esp_rx_vars.h"
#include "can_frame_structure.h"
extern uint32 count_ESP_YRS_03;
extern struct can_message_s ESP_YRS_03_rx_mes;
extern ESP_YRS_03 ESP_YRS_03_frame;
extern uint32 count_ESP_01;
extern struct can_message_s ESP_01_rx_mes;
extern ESP_01 ESP_01_frame;
extern uint32 count_ESP_03;
extern struct can_message_s ESP_03_rx_mes;
extern ESP_03 ESP_03_frame;
extern uint32 count_ESP_02;
extern struct can_message_s ESP_02_rx_mes;
extern ESP_02 ESP_02_frame;
extern uint32 count_ESP_04;
extern struct can_message_s ESP_04_rx_mes;
extern ESP_04 ESP_04_frame;
