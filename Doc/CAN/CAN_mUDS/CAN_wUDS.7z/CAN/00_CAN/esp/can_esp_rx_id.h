#ifndef ESP_RX_HANDLERS_PRIVATE_H
#define ESP_RX_HANDLERS_PRIVATE_H

#define FRAME_ESP_YRS_03_ID		(0x132)
#define FRAME_ESP_01_ID		(0x080)
#define FRAME_ESP_03_ID		(0x082)
#define FRAME_ESP_02_ID		(0x081)
#define FRAME_ESP_04_ID		(0x100)

#endif
