#include "can_esp_rx_vars.h"
#include "can_frame_structure.h"
uint32 count_ESP_YRS_03 = 0;
ESP_YRS_03 ESP_YRS_03_frame;

uint32 count_ESP_01 = 0;
ESP_01 ESP_01_frame;

uint32 count_ESP_03 = 0;
ESP_03 ESP_03_frame;

uint32 count_ESP_02 = 0;
ESP_02 ESP_02_frame;

uint32 count_ESP_04 = 0;
ESP_04 ESP_04_frame;

