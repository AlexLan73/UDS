#include "can_pt_tx_vars.h"
uint32 count_EMS_8=0;
EMS_8 EMS_8_frame; 

uint32 count_EMS_7=0;
EMS_7 EMS_7_frame; 

uint32 count_EMS_4=0;
EMS_4 EMS_4_frame; 

uint32 count_EMS_3=0;
EMS_3 EMS_3_frame; 

uint32 count_EMS_2=0;
EMS_2 EMS_2_frame; 

uint32 count_EMS_1=0;
EMS_1 EMS_1_frame; 

uint32 count_ECU_Indicators=0;
ECU_Indicators ECU_Indicators_frame; 

uint32 count_ECU_16=0;
ECU_16 ECU_16_frame; 

uint32 count_ECU_14=0;
ECU_14 ECU_14_frame; 

uint32 count_Diag_From_ECU=0;
Diag_From_ECU Diag_From_ECU_frame; 

uint32 count_EMS_HVC_Req_Msg=0;
EMS_HVC_Req_Msg EMS_HVC_Req_Msg_frame; 

uint32 count_EMS_EEM_02=0;
EMS_EEM_02 EMS_EEM_02_frame; 

uint32 count_EMS_EEM_01=0;
EMS_EEM_01 EMS_EEM_01_frame; 

uint32 count_ECU_Veh_02=0;
ECU_Veh_02 ECU_Veh_02_frame; 

uint32 count_ECU_Veh=0;
ECU_Veh ECU_Veh_frame; 

