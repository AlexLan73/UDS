#include "can_pt_rx_vars.h"
#include "can_frame_structure.h"
uint32 count_TCU_R932_5 = 0;
TCU_R932_5 TCU_R932_5_frame;

uint32 count_TCU_R932_4 = 0;
TCU_R932_4 TCU_R932_4_frame;

uint32 count_TCU_R932_3 = 0;
TCU_R932_3 TCU_R932_3_frame;

uint32 count_TCU_R932_2 = 0;
TCU_R932_2 TCU_R932_2_frame;

uint32 count_HVC_HV_Status_Msg = 0;
HVC_HV_Status_Msg HVC_HV_Status_Msg_frame;

uint32 count_Diag_To_ECU = 0;
Diag_To_ECU Diag_To_ECU_frame;

uint32 count_CDA_11 = 0;
CDA_11 CDA_11_frame;

uint32 count_VAU_EMS_Hash_Immo_RESP = 0;
VAU_EMS_Hash_Immo_RESP VAU_EMS_Hash_Immo_RESP_frame;

uint32 count_TCU_R932_1 = 0;
TCU_R932_1 TCU_R932_1_frame;

uint32 count_SAS_Standard = 0;
SAS_Standard SAS_Standard_frame;

uint32 count_EPB_Status = 0;
EPB_Status EPB_Status_frame;

uint32 count_Diag_Functional_FromPT = 0;
Diag_Functional_FromPT Diag_Functional_FromPT_frame;

uint32 count_DMS_01 = 0;
DMS_01 DMS_01_frame;

uint32 count_CCU_MSG3 = 0;
CCU_MSG3 CCU_MSG3_frame;

uint32 count_CCU_HVC_Req_Msg = 0;
CCU_HVC_Req_Msg CCU_HVC_Req_Msg_frame;

uint32 count_BCM_VEH_STATE = 0;
BCM_VEH_STATE BCM_VEH_STATE_frame;

uint32 count_BCM_Powertrain = 0;
BCM_Powertrain BCM_Powertrain_frame;

uint32 count_BCM_EEM = 0;
BCM_EEM BCM_EEM_frame;

uint32 count_ACU_01 = 0;
ACU_01 ACU_01_frame;

