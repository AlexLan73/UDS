
#ifndef CAN_CONTROLLER_SETTINGS_H
#define CAN_CONTROLLER_SETTINGS_H

#include "can_initialization.h"

extern const Can_ControllerSettingsType Can_ControllerSettings[CAN_MAX_CONTROLLERS];

#endif /* CAN_CONTROLLER_SETTINGS_H */
