#ifndef CAN_WRITE_CYCLIC_FAME_H
#define CAN_WRITE_CYCLIC_FAME_H
#include "Platform_Types.h"


extern void can_write_cyclic_frame(uint32 can_id);

#endif /* CAN_WRITE_CYCLIC_FAME_H */
