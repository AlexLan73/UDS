#ifndef CAN_READ_CYCLIC_FRAME_H
#define CAN_READ_CYCLIC_FRAME_H
#include "Platform_Types.h"
#include "can_frame_structure.h"
extern void can_read_cyclic_frame(uint32 can_id);
# endif
