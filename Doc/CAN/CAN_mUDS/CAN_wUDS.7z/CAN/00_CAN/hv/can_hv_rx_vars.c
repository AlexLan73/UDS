#include "can_hv_rx_vars.h"
#include "can_frame_structure.h"
uint32 count_Hyb_Sys_INV_05 = 0;
Hyb_Sys_INV_05 Hyb_Sys_INV_05_frame;

uint32 count_Hyb_Sys_INV_04 = 0;
Hyb_Sys_INV_04 Hyb_Sys_INV_04_frame;

uint32 count_Hyb_Sys_INV_03 = 0;
Hyb_Sys_INV_03 Hyb_Sys_INV_03_frame;

uint32 count_Hyb_Sys_INV_02 = 0;
Hyb_Sys_INV_02 Hyb_Sys_INV_02_frame;

uint32 count_Hyb_Sys_INV_01 = 0;
Hyb_Sys_INV_01 Hyb_Sys_INV_01_frame;

uint32 count_Hyb_Sys_DC_02 = 0;
Hyb_Sys_DC_02 Hyb_Sys_DC_02_frame;

uint32 count_Hyb_Sys_DC_01 = 0;
Hyb_Sys_DC_01 Hyb_Sys_DC_01_frame;

uint32 count_Hyb_Sys_BMS_04 = 0;
Hyb_Sys_BMS_04 Hyb_Sys_BMS_04_frame;

uint32 count_Hyb_Sys_BMS_03 = 0;
Hyb_Sys_BMS_03 Hyb_Sys_BMS_03_frame;

uint32 count_Hyb_Sys_BMS_02 = 0;
Hyb_Sys_BMS_02 Hyb_Sys_BMS_02_frame;

uint32 count_Hyb_Sys_BMS_01 = 0;
Hyb_Sys_BMS_01 Hyb_Sys_BMS_01_frame;

uint32 count_Diag_From_INC = 0;
Diag_From_INC Diag_From_INC_frame;

uint32 count_Diag_From_BMS = 0;
Diag_From_BMS Diag_From_BMS_frame;

uint32 count_BSC6VAL2 = 0;
BSC6VAL2 BSC6VAL2_frame;

uint32 count_BSC6VAL1 = 0;
BSC6VAL1 BSC6VAL1_frame;

