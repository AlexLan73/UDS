#include "can_hv_tx_vars.h"
uint32 count_NAMI_EMS_04=0;
NAMI_EMS_04 NAMI_EMS_04_frame; 

uint32 count_NAMI_EMS_03=0;
NAMI_EMS_03 NAMI_EMS_03_frame; 

uint32 count_NAMI_EMS_02=0;
NAMI_EMS_02 NAMI_EMS_02_frame; 

uint32 count_NAMI_EMS_01=0;
NAMI_EMS_01 NAMI_EMS_01_frame; 

uint32 count_Diag_To_INC=0;
Diag_To_INC Diag_To_INC_frame; 

uint32 count_Diag_To_BMS=0;
Diag_To_BMS Diag_To_BMS_frame; 

uint32 count_Diag_Functional=0;
Diag_Functional Diag_Functional_frame; 

uint32 count_BSC6LIM=0;
BSC6LIM BSC6LIM_frame; 

uint32 count_BSC6COM=0;
BSC6COM BSC6COM_frame; 

