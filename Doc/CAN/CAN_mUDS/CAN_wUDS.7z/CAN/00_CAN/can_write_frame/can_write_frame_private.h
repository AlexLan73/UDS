#ifndef CAN_WRITE_FRAME_PRIVATE_H
#define CAN_WRITE_FRAME_PRIVATE_H
#include "can_write_frame.h"
#include "can_initialization.h"
static IfxMultican_Message tx_mess;
#endif
