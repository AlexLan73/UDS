#ifndef CAN_CYCLIC_RX_CALLS_10
#define CAN_CYCLIC_RX_CALLS_10
void can_cyclic_rx_calls_10(void);
#endif
