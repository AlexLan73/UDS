#ifndef CAN_CYCLIC_RX_CALLS_500
#define CAN_CYCLIC_RX_CALLS_500
void can_cyclic_rx_calls_500(void);
#endif
