#ifndef CAN_CYCLIC_RX_CALLS_100
#define CAN_CYCLIC_RX_CALLS_100
void can_cyclic_rx_calls_100(void);
#endif
