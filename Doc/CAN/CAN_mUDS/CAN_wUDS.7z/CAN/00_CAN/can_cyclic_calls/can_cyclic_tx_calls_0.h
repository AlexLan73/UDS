#ifndef CAN_CYCLIC_TX_CALLS_0
#define CAN_CYCLIC_TX_CALLS_0
void can_cyclic_tx_calls_0(void);
#endif
