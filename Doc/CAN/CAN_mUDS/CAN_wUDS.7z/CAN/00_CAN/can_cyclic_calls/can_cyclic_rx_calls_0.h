#ifndef CAN_CYCLIC_RX_CALLS_0
#define CAN_CYCLIC_RX_CALLS_0
void can_cyclic_rx_calls_0(void);
#endif
