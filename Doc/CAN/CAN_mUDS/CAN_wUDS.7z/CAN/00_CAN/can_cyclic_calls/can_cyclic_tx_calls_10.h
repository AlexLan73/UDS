#ifndef CAN_CYCLIC_TX_CALLS_10
#define CAN_CYCLIC_TX_CALLS_10
void can_cyclic_tx_calls_10(void);
#endif
