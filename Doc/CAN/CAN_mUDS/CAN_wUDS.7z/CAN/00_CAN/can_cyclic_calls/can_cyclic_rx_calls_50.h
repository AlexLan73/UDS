#ifndef CAN_CYCLIC_RX_CALLS_50
#define CAN_CYCLIC_RX_CALLS_50
void can_cyclic_rx_calls_50(void);
#endif
