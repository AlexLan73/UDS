#ifndef CAN_CYCLIC_RX_CALLS_20
#define CAN_CYCLIC_RX_CALLS_20
void can_cyclic_rx_calls_20(void);
#endif
