#ifndef CAN_CYCLIC_TX_CALLS_20
#define CAN_CYCLIC_TX_CALLS_20
void can_cyclic_tx_calls_20(void);
#endif
