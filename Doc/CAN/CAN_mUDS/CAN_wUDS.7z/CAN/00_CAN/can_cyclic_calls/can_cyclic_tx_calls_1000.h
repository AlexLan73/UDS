#ifndef CAN_CYCLIC_TX_CALLS_1000
#define CAN_CYCLIC_TX_CALLS_1000
void can_cyclic_tx_calls_1000(void);
#endif
