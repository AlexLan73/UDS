#ifndef CALC_CRC8_H
#define CALC_CRC8_H

#include "Platform_Types.h"
extern uint8 calc_CRC8(uint8* buffer_pu8, uint8 dlc_u8, uint8 bitpos_u8);

#endif /* CALC_CRC8_H */
