#ifndef CALC_CHKSUM_XOR_H
#define CALC_CHKSUM_XOR_H

#include "Platform_Types.h"
extern uint8 calc_chksum_XOR8(uint8* buffer_pu8, uint8 dlc_u8, uint8 bitpos_u8);

#endif /* CALC_CHKSUM_XOR_H */
